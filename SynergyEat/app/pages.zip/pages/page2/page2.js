import {Page} from 'ionic-angular';


@Page({
  templateUrl: 'build/pages/page2/page2.html'
})
export class Page2 {
  constructor() {

  }
}


