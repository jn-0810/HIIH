import {Page} from 'ionic-angular';
import {RedIce} from '../RedIce/RedIce'

@Page({
  templateUrl: 'build/pages/page1/page1.html'
}) 
export class Page1 {
  constructor() { 
    
  }
}
